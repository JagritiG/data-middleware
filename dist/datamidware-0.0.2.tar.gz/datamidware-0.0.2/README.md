Datamidware: Data Middleware
----------------------------------------------------


    datamidware/
            pyalgo/

                Python algorithm modules

            pydp/

                Python data processing modules

            pydb/

                Python database interface modules
            pyviz/

                Python data visualization modules
            pydm/

                Python data middleware

            docs/
                    Document files

            tests/
                    All test modules and test data

            settings/

                    Installation and setup modules
                    Config files






